// missionUtils.test.js

// Підключаємо модуль assert для перевірки результатів
const   assert = require('assert');
// або можна використати Chai:
// const { expect } = require('chai');

// Імпортуємо наші функції з іншого файлу
const {    calculateAmmoNeeded , isMissionReady   } = require('./missionUtils');

// Тести українською для наочності
// describe - це група тестів
// it - це окремий тест

describe('Тести для Mission Utils',   ( ) => {
    // Тестуємо функцію calculateAmmoNeeded
    it('повинно повернути 300 для 10 солдатів і 30 патронів на кожного',   ( ) => {
        const   result = calculateAmmoNeeded(10, 30); // викликаємо функцію
        assert.strictEqual(result, 300); // перевіряємо, чи результат 300
    });

    // Тестуємо, коли патронів вистачає
    it('повинно повернути true, коли ammoAvailable (500) достатньо для ammoNeeded (300)',   () => {
        const result = isMissionReady(500, 300); // викликаємо функцію
        assert.strictEqual(result, true); // перевіряємо, чи результат true
    });

    // Тестуємо, коли патронів не вистачає
    it('повинно повернути false, коли ammoAvailable (200) недостатньо для ammoNeeded (300)',   () => {
        const result = isMissionReady(200, 300); // викликаємо функцію
        assert.strictEqual(result, false); // перевіряємо, чи результат false
    });
});
