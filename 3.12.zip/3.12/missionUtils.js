// missionUtils.js

// Функція рахує скільки всього треба патронів
function    calculateAmmoNeeded(soldiers,   roundsPerSoldier ) {
    return soldiers   * roundsPerSoldier ;
}

// Функція перевіряє, чи вистачає патронів для місії
function isMissionReady( ammoAvailable , ammoNeeded ) {
    return ammoAvailable >= ammoNeeded ;
}

// Експортуємо наші функції, щоб їх можна було тестувати
module.exports = {
    calculateAmmoNeeded ,
    isMissionReady
};
