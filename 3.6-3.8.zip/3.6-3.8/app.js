const express = require('express');
const app = express();
const vehicleRoutes = require('./routes/vehicleRoutes');

app.use(express.json());
app.use(express.static('public')); // Віддаємо фронтенд

app.use('/api/vehicles', vehicleRoutes);

const PORT = 3000;
app.listen(PORT, () => {
  console.log(`http://localhost:3000/login.html Порт ${PORT}`);
});
