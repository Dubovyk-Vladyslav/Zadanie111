const express = require('express');
const router = express.Router();
const controller = require('../controllers/vehicleController');

router.get('/', controller.getAllVehicles);
router.get('/:id', controller.getVehicleById);
router.post('/', controller.addVehicle);
router.put('/:id', controller.updateVehicle);
router.delete('/:id', controller.deleteVehicle);

module.exports = router;
