// Простий кеш із node-cache
const NodeCache = require('node-cache');
const cache = new NodeCache({ stdTTL: 60 }); // TTL — 60 секунд

module.exports = cache;
