const Model = require('../models/vehicleModel');

exports.getAllVehicles = (req, res) => {
  res.json(Model.getAll());
};

exports.getVehicleById = (req, res) => {
  const id = Number(req.params.id);
  const vehicle = Model.getById(id);
  if (!vehicle) return res.status(404).json({ message: "Техніка не знайдена" });
  res.json(vehicle);
};

exports.addVehicle = (req, res) => {
  const newVehicle = req.body;
  if (!newVehicle.type || !newVehicle.model || !newVehicle.status) {
    return res.status(400).json({ message: "Відсутні обов’язкові поля" });
  }
  const added = Model.add(newVehicle);
  res.status(201).json(added);
};

exports.updateVehicle = (req, res) => {
  const id = Number(req.params.id);
  const updatedData = req.body;
  const updated = Model.update(id, updatedData);
  if (!updated) return res.status(404).json({ message: "Техніка не знайдена" });
  res.json(updated);
};

exports.deleteVehicle = (req, res) => {
  const id = Number(req.params.id);
  const removed = Model.remove(id);
  if (!removed) return res.status(404).json({ message: "Техніка не знайдена" });
  res.json({ message: "Видалено" });
};
