// підключаю різні модулі
const { addUser } = require('./models/user')
const express = require('express')
const session = require('express-session')
const passport = require('passport')
const initializePassport = require('./passport-config')
const vehicleRoutes = require('./routes/vehicleRoutes')
const path = require('path')

// створюю додаток
const app = express()

// ініціалізую passport
initializePassport(passport)

// підключаю різні middleware
app.use(express.json())
app.use(express.urlencoded({ extended: false }))
app.use(express.static('public'))

// налаштування сесій
app.use(session({
 secret: 'secretkey',
 resave: false,
 saveUninitialized: false
}))
app.use(passport.initialize())
app.use(passport.session())

// функція для перевірки чи залогінений користувач
function ensureAuthenticated(req, res, next) {
    if (req.isAuthenticated()) {
        return next()
    }
    res.redirect('/login.html') // якщо не залогінений, то на сторінку входу
}

// логін
app.post('/login', passport.authenticate('local', {
    successRedirect: '/index.html',
    failureRedirect: '/login.html'
}))

// вихід
app.get('/logout', (req, res) => {
    req.logout(() => {
        res.redirect('/login.html')
    })
})

// захищені маршрути для техніки
app.use('/api/vehicles', ensureAuthenticated, vehicleRoutes)

// захищена сторінка (можна додати ще)
app.get('/main.html', ensureAuthenticated, (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'main.html'))
})

// головна сторінка після входу
app.get('/index.html', ensureAuthenticated, (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'))
})

// якщо просто зайшли на сайт — редірект на логін
app.get('/', (req, res) => {
    res.redirect('/login.html')
})

// реєстрація нового користувача
app.post('/register', (req, res) => {
    const { username, password } = req.body
    if (!username || !password) {
        return res.status(400).send('Введіть логін і пароль')
    }
    if (!addUser(username, password)) {
        return res.status(409).send('Користувач вже існує')
    }
    res.redirect('/login.html')
})

// запускаю сервер
const PORT = 3000
app.listen(PORT, () => {
    console.log('http://localhost:3000/login.html Порт ' + PORT)
})
