// тут зберігаються користувачі
const bcrypt = require('bcryptjs')

// масив користувачів (початково один адмін)
const users = [
    {
        id: 1,
        username: 'admin',
        password: bcrypt.hashSync('admin123', 10)
    }
]

// функція для додавання нового користувача
function addUser(username, password) {
    // якщо такий вже є — не додаємо
    if (users.find(u => u.username === username)) return false
    const id = users.length ? users[users.length - 1].id + 1 : 1
    users.push({ id, username, password: bcrypt.hashSync(password, 10) })
    return true
}

// експортуємо функції для роботи з користувачами
module.exports = {
    findUser: (username) => users.find(u => u.username === username),
    findUserById: (id) => users.find(u => u.id === id),
    validatePassword: (user, password) => bcrypt.compareSync(password, user.password),
    addUser
}
