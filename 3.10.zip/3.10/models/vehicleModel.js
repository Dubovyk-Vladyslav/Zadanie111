// models/vehicleModel.js

let vehicles = [
  { id: 1, type: "танк", model: "Т-64", status: "активний" },
  { id: 2, type: "БТР", model: "БТР-4", status: "в ремонті" }
];

// Лічильник для унікальних ID, починаємо з останнього існуючого ID
let currentId = vehicles.length > 0 ? vehicles[vehicles.length - 1].id : 0;

function getAll() {
  return vehicles;
}

function getById(id) {
  return vehicles.find(v => v.id === id);
}

function add(vehicle) {
  currentId += 1;      // збільшуємо лічильник
  vehicle.id = currentId;
  vehicles.push(vehicle);
  return vehicle;
}

function update(id, updated) {
  const index = vehicles.findIndex(v => v.id === id);
  if (index === -1) return null;
  vehicles[index] = { id, ...updated };
  return vehicles[index];
}

function remove(id) {
  const index = vehicles.findIndex(v => v.id === id);
  if (index === -1) return false;
  vehicles.splice(index, 1);
  return true;
}

module.exports = { getAll, getById, add, update, remove };
