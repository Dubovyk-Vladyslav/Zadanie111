// тут налаштовується passport
const LocalStrategy = require('passport-local').Strategy
const { findUser, findUserById, validatePassword } = require('./models/user')

function initialize(passport) {
    // стратегія логіну
    passport.use(new LocalStrategy((username, password, done) => {
        const user = findUser(username)
        if (!user) return done(null, false, { message: 'No user' }) // якщо нема такого
        if (!validatePassword(user, password)) return done(null, false, { message: 'Wrong password' }) // якщо пароль не підходить
        return done(null, user)
    }))

    // серіалізація користувача (зберігаємо id в сесії)
    passport.serializeUser((user, done) => done(null, user.id))
    // десеріалізація (знаходимо користувача по id)
    passport.deserializeUser((id, done) => {
        const user = findUserById(id)
        if (user) done(null, user)
        else done(null, false)
    })
}

module.exports = initialize
