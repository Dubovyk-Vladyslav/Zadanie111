const { MongoClient } = require('mongodb');
const readline = require('readline');

  // Підключення до MongoDB
const url = 'mongodb://localhost:27017';
const dbName = 'armyDB';
const collectionName = 'personnel';
const client = new MongoClient(url);    

        // Інтерфейс читання з терміналу
const rl = readline.createInterface({
   input: process.stdin,
  output: process.stdout
});

    // Проста функція запитання в консолі
function ask(question) {
  return new Promise(resolve => rl.question(question, answer => resolve(answer)));
}

// Функція генерації нового короткого ID
        async function generateId(collection) {
  const existing = await collection.find({ id: { $exists: true } }).toArray();
     const numbers = existing.map(p => parseInt(p.id?.substring(2))).filter(n => !isNaN(n));
  const next = numbers.length > 0 ? Math.max(...numbers) + 1 : 1;
  return 'VS' + String(next).padStart(3, '0');
}

    async function main() {
  await client.connect();
  const db = client.db(dbName);
     const collection = db.collection(collectionName);

  
  
     while (true) {
    console.log('\n--- Меню ---');
    console.log('1. Додати військового');
    console.log('2. Показати всіх');
    console.log('3. Показати одного');
    console.log('4. Редагувати');
    console.log('5. Видалити');
    console.log('6. Очистити записи без ID');
    console.log('0. Вийти');

       const choice = await ask('Ваш вибір: ');

    if (choice === '1') {
          const name = await ask('Імʼя: ');
      const surname = await ask('Прізвище: ');
      const rank = await ask('Звання: ');
      const position = await ask('Посада: ');
      const dateOfBirth = await ask('Дата народження (YYYY-MM-DD): ');
      const notes = await ask('Примітки: ');

      const shortId = await generateId(collection);
      await collection.insertOne({ id: shortId, name, surname, rank, position, dateOfBirth, notes });
              console.log(` Додано з ID: ${shortId}`);
    }

    else if (choice === '2') {
      const people = await collection.find().toArray();
      console.log(' Весь особовий склад:');
           people.forEach(p => {
        if (p.id) {
          console.log(`${p.id}: ${p.rank} ${p.name} ${p.surname}`);
        } else {
          console.log(`(без ID): ${p.rank} ${p.name} ${p.surname}`);
        }
      });
    }

     else if (choice === '3') {
          const id = await ask('Введіть короткий ID (наприклад VS001): ');
      try {
        const person = await collection.findOne({ id: id });
        if (person) {
          console.log(' Деталі:');
          console.log(person);
        } else {
          console.log(' Не знайдено.');
        }
      } catch {
        console.log(' Неправильний ID.');
      }
    }

        else if (choice === '4') {
      const id = await ask('Введіть ID для редагування: ');
      try {
        const field = await ask('Яке поле змінити (name, surname, rank, position, dateOfBirth, notes): ');
             const newValue = await ask('Нове значення: ');
        await collection.updateOne({ id: id }, { $set: { [field]: newValue } });
           console.log(' Дані оновлено.');
      } catch {
        console.log(' Помилка при редагуванні.');
      }
    }

    else if (choice === '5') {
         const id = await ask('Введіть ID для видалення: ');
      try {
        await collection.deleteOne({ id: id });
        console.log(' Видалено.');
      } catch {
        console.log(' Неправильний ID.');
      }
    }

    else if (choice === '6') {
          const result = await collection.deleteMany({ id: { $exists: false } });
      console.log(` Видалено ${result.deletedCount} записів без ID.`);
    }

    else if (choice === '0') {
      break;
    }

    else {
      console.log('❗ Невірний вибір. Спробуйте ще раз.');
    }
  }

  await client.close();
  rl.close();
  console.log(' Програма завершена.');
}

main();
