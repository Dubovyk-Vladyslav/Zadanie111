const express = require('express')
const fs = require('fs')
const path = require('path')

const app = express()
const PORT = 3000

app.set('view engine', 'ejs')
app.use(express.urlencoded({ extended: true }))
app.use(express.static('public'))

let userData = {} // тимчасове зберігання ім’я та прізвище

// показуємо форму входу
app.get('/', (req, res) => {
  res.render('login')
})

// початок тесту
app.post('/start', (req, res) => {
  userData = {
    name: req.body.name,
    lastname: req.body.lastname
  }
  const test = JSON.parse(fs.readFileSync('test.json', 'utf-8'))
  res.render('test', { test: test, user: userData })
})

// middleware для збереження результатів
function saveResult(req, res, next) {
  const answers = req.body
  const test = JSON.parse(fs.readFileSync('test.json', 'utf-8'))
  let correct = 0

  for (let key in test) {
    if (answers[key] === test[key].correct) {
      correct++
    }
  }

  const resultEntry = {
    name: req.body.name,
    lastname: req.body.lastname,
    total: Object.keys(test).length,
    correct: correct
  }

  let allResults = []
  const file = 'results.json'

  if (fs.existsSync(file)) {
    const content = fs.readFileSync(file, 'utf-8').trim()
    if (content) allResults = JSON.parse(content)
  }

  allResults.push(resultEntry)
  fs.writeFileSync(file, JSON.stringify(allResults, null, 2))

  req.correct = correct
  req.test = test
  req.answers = answers
  next()
}

// завершення тесту
app.post('/submit', saveResult, (req, res) => {
  res.render('result', {
    user: { name: req.body.name, lastname: req.body.lastname },
    test: req.test,
    answers: req.answers,
    correct: req.correct,
    total: Object.keys(req.test).length
  })
})

app.listen(PORT, () => {
  console.log(`http://localhost:${PORT}`)
})
