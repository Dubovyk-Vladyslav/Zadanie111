const express = require('express')      // підключаємо фреймворк
const fs = require('fs')                // модуль для роботи з файлами
const path = require('path')            // модуль для зручної роботи з шляхами
const app = express()
const PORT = 3000

// кажемо серверу, де шукати html-файли
app.use(express.static(path.join(__dirname, 'public')))

// створюємо маршрут, який буде викликатись після натискання кнопки
app.get('/save', (req, res) => {
    // беремо IP-адресу клієнта
    const ip = req.ip

    // порт (може бути 0 якщо не вказаний, це нормально)
    const port = req.connection.remotePort

    // беремо поточну дату і час
    const date = new Date()
    const formattedDate = date.toLocaleString() // формат: "дата година"

    // читаємо існуючі дані з файлу (якщо файл існує)
    let data = {}
    if (fs.existsSync('client.json')) {
        const raw = fs.readFileSync('client.json', 'utf-8')
    
        if (raw.trim() !== '') {
            // якщо файл не порожній — парсимо
            data = JSON.parse(raw)
        } else {
            // якщо файл порожній — просто залишаємо data = {}
        }
    }
    

    // додаємо новий запис з новим номером
    const newId = Object.keys(data).length + 1
    data[newId] = {
        IpAddrClient: ip,
        port: port,
        Time: formattedDate
    }

    // записуємо нові дані у файл
    fs.writeFileSync('client.json', JSON.stringify(data, null, 2))

    // відправляємо відповідь
    res.send('Дані збережено!')
})

// запускаємо сервер
app.listen(PORT, () => {
    console.log(`Сервер запущено на порту ${PORT}`)
})
